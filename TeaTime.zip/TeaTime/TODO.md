###TO DO!

- More and better examples
- A decent stress test
- Maybe a TeaTime manager will be better
- Improve time precision ^
- Use arrays instead of generic lists ^

x Yoyo mode (Forward, Backward cycle)
x A good testing to Reverse/Backward/Forward mode
x Rewrite the main algorithm to optimize coroutine instantiation
x Replace Foreachs by For
x TeaTime should be able to wait other TeaTimes
x Lots of things before starting this to-do
