###TODO

- **core** Fuse the main queue & blueprints logic into a 'next level' algorithm (waat)
- **examples** AHHHH!
- **feature** Global Stop (Could be Reset with options)
- **feature** Global Pause
- **feature** Global Play

2015/05/03 10:53:20 PM
