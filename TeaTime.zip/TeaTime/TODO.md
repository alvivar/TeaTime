###TO DO!

- More and better examples
- Using arrays instead of generic lists :(
- Stress test on main platforms
- Improve time precision

x TeaTime should be able to wait other TeaTime
x Lots of things before starting this to-do
