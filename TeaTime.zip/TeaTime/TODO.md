###TODO

- **core** Fuse the main queue & blueprints logic into a 'next level' algorithm (waat)?
- **unfinished** Reset must include blueprints
- **ttGet** Returns an IEnumerator that represents que current queue
- **examples** AHHHH!
- **feature** Global Stop (Could be Reset with options)
- **feature** Global Pause
- **feature** Global Play

2015/06/19 05:55:25 PM
