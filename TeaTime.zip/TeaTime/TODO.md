###TODO

- **examples** AHHHH!
- **feature** Global Stop (Could be Reset with options)
- **feature** Global Pause
- **feature** Global Play
- **bug** Instantly nested queues problem is an antipattern? of bug?

2015/04/28 02:57:35 PM
