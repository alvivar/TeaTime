# TO DO

- More and better examples
- A decent stress test
- A TeaTime manager that runs everything
- Pool cache support
- Improve time precision ^
- Use arrays instead of generic lists ^

## DONE

- Yoyo mode (Forward, Backward cycle)
- A good testing to Reverse/Backward/Forward mode
- Rewrite the main algorithm to optimize coroutine instantiation
- Replace Foreachs by For
- TeaTime should be able to wait other TeaTimes
- Lots of things before starting this to-do
