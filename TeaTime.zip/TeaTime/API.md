
###TeaTime API v0.7.4b

**Timed Callbacks**
- **.Add(**
- **.Loop(**

**Queue Modes**
- **.Immutable()**
- **.Repeat()**
- **.Consume()**

**Control**
- **.Play()**
- **.Pause()**
- **.Stop()**
- **.Restart()**
- **.Unlock()**

**Special**
- **.If(Func<bool>)**

**Destructive**
- **.Reset()**
