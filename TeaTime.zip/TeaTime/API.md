
###TeaTime API v0.7.7 beta

**Timed Callbacks**
- **.Add(**
- **.Loop(**

**Queue Modes**
- **.Immutable()**
- **.Repeat()**
- **.Consume()**
- **.Release()**

**Control**
- **.Pause()**
- **.Stop()**
- **.Play()**
- **.Restart()**

**Destruction**
- **.Reset()**

**Special**
- **.If(Func<bool>)**

**Custom Yields**
- **.WaitForCompletion()**
