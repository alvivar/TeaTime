
###TeaTime API v0.7a


**Timed Callbacks**
- .Add(
- .Loop(

**Queue Modes**
- .Wait()
- .Repeat()
- .Consume()

**Control**
- .Play()
- .Pause()
- .Stop()
- .Restart()
- .Unlock()

**Destructive**
- .Reset()
