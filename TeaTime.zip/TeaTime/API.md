
###TeaTime API

**Timed Callbacks**
- **.Add(**
- **.Loop(**

**Queue Modes**
- **.Immutable()**
- **.Repeat()**
- **.Consume()**
- **.Reverse()**
- **.Backward()**
- **.Forward()**
- **.Yoyo()**

**Control**
- **.Pause()**
- **.Stop()**
- **.Play()**
- **.Restart()**
- **.Release()**

**Destruction**
- **.Reset()**

**Special**
- **.If(Func<bool>)**

**Custom Yields**
- **.WaitForCompletion()**
