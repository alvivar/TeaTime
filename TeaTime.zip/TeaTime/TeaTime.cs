﻿// TeaTime v0.6.5 alpha

// By Andrés Villalobos [andresalvivar@gmail.com twitter.com/matnesis]
// Special thanks to Antonio Zamora [twitter.com/tzamora] (loop idea and initial push).
// Created 2014/12/26 12:21 am

// TeaTime is a fast & simple queue for timed callbacks, fashioned as a
// MonoBehaviour extension set, focused on solving common coroutines patterns in
// Unity games.

// Just put 'TeaTime.cs' somewhere in your project and call it inside any
// MonoBehaviour using 'this.tt' (and trust the autocomplete).


//    this.tt("QueueExample").ttAdd(2, () =>
//    {
//        Debug.Log("2 seconds since QueueExample started " + Time.time);
//    })
//    .ttLoop(3, delegate(ttHandler loop)
//    {
//        // ttLoop runs frame by frame for all his duration (3s) and his handler have a
//        // custom delta (loop.deltaTime) that represents the precise loop duration.
//        Camera.main.backgroundColor
//            = Color.Lerp(Camera.main.backgroundColor, Color.black, loop.deltaTime);
//    })
//    .ttAdd(() =>
//    {
//        Debug.Log("5 seconds since QueueExample started " + Time.time);
//    })


// Check out the examples!
// [http://github.com/alvivar/TeaTime/tree/master/Examples] to learn with
// practical patterns! (*More to come*)


// Copyright (c) 2014/12/26 andresalvivar@gmail.com

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.


using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/// <summary>
/// TeaTime task (queue data).
/// </summary>
public class ttTask
{
    public MonoBehaviour instance;
    public string queueName;
    public float time = 0f;
    public YieldInstruction yieldInstruction = null;
    public Action callback = null;
    public Action<ttHandler> callbackWithHandler = null;
    public bool isLoop = false;


    public ttTask(MonoBehaviour instance, string queueName, float time, YieldInstruction yield, Action callback, Action<ttHandler> callbackWithHandler, bool isLoop)
    {
        this.instance = instance;
        this.queueName = queueName;
        this.time = time;
        this.yieldInstruction = yield;
        this.callback = callback;
        this.callbackWithHandler = callbackWithHandler;
        this.isLoop = isLoop;
    }
}


/// <summary>
/// TeaTime callback handler.
/// </summary>
public class ttHandler
{
    public bool isActive = true;
    public float t = 0f;
    public float deltaTime = 0f;
    public float timeSinceStart = 0f;
    public YieldInstruction yieldToWait = null;


    /// <summary>
    /// Breaks the current loop.
    /// </summary>
    public void Break()
    {
        this.isActive = false;
    }


    /// <summary>
    /// Waits for a time interval after the current callback.
    /// </summary>
    public void WaitFor(float interval)
    {
        this.yieldToWait = new WaitForSeconds(interval);
    }


    /// <summary>
    /// Waits for a YieldInstruction after the current callback.
    /// </summary>
    public void WaitFor(YieldInstruction yieldToWait)
    {
        this.yieldToWait = yieldToWait;
    }
}


/// <summary>
/// TeaTime is a fast & simple queue for timed callbacks, fashioned as a
/// MonoBehaviour extension set, focused on solving common coroutines patterns in
/// Unity games.
/// </summary>
public static class TeaTime
{
    /// <summary>
    /// Debug mode prints queue interactions on console.
    /// </summary>
    public static bool debugMode = false;

    /// <summary>
    /// Default queue name.
    /// </summary>
    private const string DEFAULT_QUEUE_NAME = "DEFAULT_QUEUE_NAME";

    /// <summary>
    /// Main queue for all the timed callbacks.
    /// #todo This can be optimized by using blueprints (below), maybe.
    /// </summary>
    private static Dictionary<MonoBehaviour, Dictionary<string, List<ttTask>>> mainQueue = null;

    /// <summary>
    /// Contains a complete copy of every queue and their respective callbacks.
    /// </summary>
    private static Dictionary<MonoBehaviour, Dictionary<string, List<ttTask>>> blueprints = null;

    /// <summary>
    /// Current queue name.
    /// </summary>
    private static Dictionary<MonoBehaviour, string> currentQueueName = null;

    /// <summary>
    /// Queues currently running.
    /// </summary>
    private static Dictionary<MonoBehaviour, List<string>> runningQueues = null;

    /// <summary>
    /// Queues locked by ttWait().
    /// </summary>
    private static Dictionary<MonoBehaviour, List<string>> lockedQueues = null;

    /// <summary>
    /// Queues pauses by ttPause().
    /// </summary>
    private static Dictionary<MonoBehaviour, List<string>> pausedQueues = null;

    /// <summary>
    /// Infinite queues by ttRepeat(-1).
    /// </summary>
    private static Dictionary<MonoBehaviour, List<string>> infiniteQueues = null;

    /// <summary>
    /// Coroutines running in the instance, by queue name.
    /// </summary>
    private static Dictionary<MonoBehaviour, Dictionary<string, List<IEnumerator>>> runningCoroutines = null;


    /// <summary>
    /// Prepares the main queue for the instance (and the blueprints register).
    /// </summary>
    private static void PrepareMainQueue(MonoBehaviour instance, string queueName = null)
    {
        // Main queue
        if (mainQueue == null)
            mainQueue = new Dictionary<MonoBehaviour, Dictionary<string, List<ttTask>>>();

        if (!mainQueue.ContainsKey(instance))
            mainQueue.Add(instance, new Dictionary<string, List<ttTask>>());

        // Blueprints
        if (blueprints == null)
            blueprints = new Dictionary<MonoBehaviour, Dictionary<string, List<ttTask>>>();

        if (!blueprints.ContainsKey(instance))
            blueprints.Add(instance, new Dictionary<string, List<ttTask>>());

        // Task list for both
        if (queueName != null)
        {
            if (!mainQueue[instance].ContainsKey(queueName))
                mainQueue[instance].Add(queueName, new List<ttTask>());

            if (!blueprints[instance].ContainsKey(queueName))
                blueprints[instance].Add(queueName, new List<ttTask>());
        }
    }


    /// <summary>
    /// Prepares the dictionary for the current queue name (last used) in the instance.
    /// </summary>
    private static void PrepareCurrentQueueName(MonoBehaviour instance)
    {
        if (currentQueueName == null)
            currentQueueName = new Dictionary<MonoBehaviour, string>();

        // Default name
        if (!currentQueueName.ContainsKey(instance))
            currentQueueName[instance] = DEFAULT_QUEUE_NAME;
    }


    /// <summary>
    /// Prepares the dictionary for the queues running in the instance.
    /// </summary>
    private static void PrepareRunningQueues(MonoBehaviour instance)
    {
        if (runningQueues == null)
            runningQueues = new Dictionary<MonoBehaviour, List<string>>();

        if (!runningQueues.ContainsKey(instance))
            runningQueues.Add(instance, new List<string>());
    }


    /// <summary>
    /// Prepares the dictionary for the queues locked in the instance.
    /// </summary>
    private static void PrepareLockedQueues(MonoBehaviour instance)
    {
        if (lockedQueues == null)
            lockedQueues = new Dictionary<MonoBehaviour, List<string>>();

        if (!lockedQueues.ContainsKey(instance))
            lockedQueues.Add(instance, new List<string>());
    }


    /// <summary>
    /// Prepares the dictionary for the queues paused in the instance.
    /// </summary>
    private static void PreparePausedQueues(MonoBehaviour instance)
    {
        if (pausedQueues == null)
            pausedQueues = new Dictionary<MonoBehaviour, List<string>>();

        if (!pausedQueues.ContainsKey(instance))
            pausedQueues.Add(instance, new List<string>());

    }


    /// <summary>
    /// Prepares the dictionary for the infinite queues in the instance.
    /// </summary>
    private static void PrepareInfiniteQueues(MonoBehaviour instance)
    {
        if (infiniteQueues == null)
            infiniteQueues = new Dictionary<MonoBehaviour, List<string>>();

        if (!infiniteQueues.ContainsKey(instance))
            infiniteQueues.Add(instance, new List<string>());
    }


    /// <summary>
    /// Prepares the dictionary for the coroutines running in the instance.
    /// </summary>
    private static void PrepareRunningCoroutines(MonoBehaviour instance, string queueName = null)
    {
        if (runningCoroutines == null)
            runningCoroutines = new Dictionary<MonoBehaviour, Dictionary<string, List<IEnumerator>>>();

        if (!runningCoroutines.ContainsKey(instance))
            runningCoroutines.Add(instance, new Dictionary<string, List<IEnumerator>>());

        if (queueName != null)
        {
            if (!runningCoroutines[instance].ContainsKey(queueName))
                runningCoroutines[instance].Add(queueName, new List<IEnumerator>());
        }
    }


    /// <summary>
    /// Returns true if a queue is locked.
    /// </summary>
    private static bool IsLocked(MonoBehaviour instance, string queueName)
    {
        PrepareLockedQueues(instance);

        return lockedQueues[instance].Contains(queueName);
    }


    /// <summary>
    /// Returns true if a queue is paused.
    /// </summary>
    private static bool IsPaused(MonoBehaviour instance, string queueName)
    {
        PreparePausedQueues(instance);

        return pausedQueues[instance].Contains(queueName);
    }


    /// <summary>
    /// Returns true if a queue is infinite.
    /// </summary>
    private static bool IsInfinite(MonoBehaviour instance, string queueName)
    {
        PrepareInfiniteQueues(instance);

        return infiniteQueues[instance].Contains(queueName);
    }


    /// <summary>
    /// Appends a callback (timed or looped) into a queue.
    /// </summary>
    private static MonoBehaviour ttAdd(this MonoBehaviour instance, float timeDelay, YieldInstruction yieldDelay,
                                       Action callback, Action<ttHandler> callbackWithHandler,
                                       bool isLoop)
    {
        PrepareCurrentQueueName(instance);
        string queueName = currentQueueName[instance];

        // Ignore locked
        if (IsLocked(instance, queueName))
            return instance;

        PrepareMainQueue(instance, queueName);

        // Adds a new task into the main queue and blueprints
        ttTask currentTask = new ttTask(instance, queueName, timeDelay, yieldDelay, callback, callbackWithHandler, isLoop);
        mainQueue[instance][queueName].Add(currentTask);
        blueprints[instance][queueName].Add(currentTask);

        // Execute the queue unless is paused
        if (!IsPaused(instance, queueName))
            instance.StartCoroutine(ExecuteQueue(instance, queueName));

        return instance;
    }


    /// <summary>
    /// Appends a timed callback into the current queue.
    /// </summary>
    public static MonoBehaviour ttAdd(this MonoBehaviour instance, float timeDelay, Action callback)
    {
        return instance.ttAdd(timeDelay, null, callback, null, false);
    }


    /// <summary>
    /// Appends a timed callback into the current queue.
    /// </summary>
    public static MonoBehaviour ttAdd(this MonoBehaviour instance, float timeDelay, Action<ttHandler> callback)
    {
        return instance.ttAdd(timeDelay, null, null, callback, false);
    }


    /// <summary>
    /// Appends a timed callback into the current queue.
    /// </summary>
    public static MonoBehaviour ttAdd(this MonoBehaviour instance, YieldInstruction yieldToWait, Action callback)
    {
        return instance.ttAdd(0, yieldToWait, callback, null, false);
    }


    /// <summary>
    /// Appends a timed callback into the current queue.
    /// </summary>
    public static MonoBehaviour ttAdd(this MonoBehaviour instance, YieldInstruction yieldToWait, Action<ttHandler> callback)
    {
        return instance.ttAdd(0, yieldToWait, null, callback, false);
    }


    /// <summary>
    /// Appends a timed interval into the current queue.
    /// </summary>
    public static MonoBehaviour ttAdd(this MonoBehaviour instance, float interval)
    {
        return instance.ttAdd(interval, null, null, null, false);
    }


    /// <summary>
    /// Appends a callback into the current queue.
    /// </summary>
    public static MonoBehaviour ttAdd(this MonoBehaviour instance, Action callback)
    {
        return instance.ttAdd(0, null, callback, null, false);
    }


    /// <summary>
    /// Appends a callback into the current queue.
    /// </summary>
    public static MonoBehaviour ttAdd(this MonoBehaviour instance, Action<ttHandler> callback)
    {
        return instance.ttAdd(0, null, null, callback, false);
    }


    /// <summary>
    /// Appends into the current queue a callback that runs frame by frame for all his duration or until ttHandler.Break().
    /// </summary>
    public static MonoBehaviour ttLoop(this MonoBehaviour instance, float duration, Action<ttHandler> callback)
    {
        return instance.ttAdd(duration, null, null, callback, true);
    }


    /// <summary>
    /// Appends into the current queue an (infinite) callback that runs frame by frame until ttHandler.Break().
    /// </summary>
    public static MonoBehaviour ttLoop(this MonoBehaviour instance, Action<ttHandler> callback)
    {
        return instance.ttAdd(0, null, null, callback, true);
    }


    /// <summary>
    /// Wait for completion.
    /// Locks the current queue ignoring new appends until all his callbacks are completed.
    /// </summary>
    public static MonoBehaviour ttWait(this MonoBehaviour instance)
    {
        PrepareMainQueue(instance);
        PrepareCurrentQueueName(instance);

        // Ignore if the queue is empty
        if (!mainQueue[instance].ContainsKey(currentQueueName[instance]) || mainQueue[instance][currentQueueName[instance]].Count < 1)
            return instance;

        // Locks the queue
        if (!IsLocked(instance, currentQueueName[instance]))
            lockedQueues[instance].Add(currentQueueName[instance]);

        return instance;
    }


    /// <summary>
    /// Pauses the current queue (use .ttPlay() to resume).
    /// </summary>
    public static MonoBehaviour ttPause(this MonoBehaviour instance)
    {
        PrepareCurrentQueueName(instance);

        // Pauses the queue
        if (!IsPaused(instance, currentQueueName[instance]))
            pausedQueues[instance].Add(currentQueueName[instance]);

        return instance;
    }


    /// <summary>
    /// Stops and pauses the current queue (use .ttPlay() to restart).
    /// </summary>
    public static MonoBehaviour ttStop(this MonoBehaviour instance)
    {
        PrepareCurrentQueueName(instance);
        string queueName = currentQueueName[instance];

        // Resetting only the callbacks containers
        // (Leaving the queue config as they are)
        PrepareMainQueue(instance, queueName);
        PrepareRunningQueues(instance);
        PrepareRunningCoroutines(instance, queueName);

        // Clean queue callbacks
        mainQueue[instance][queueName].Clear();

        if (runningQueues[instance].Contains(queueName))
            runningQueues[instance].Remove(queueName);

        // Stop & clean coroutines
        foreach (IEnumerator coroutine in runningCoroutines[instance][queueName])
        {
            instance.StopCoroutine(coroutine);
        }
        runningCoroutines[instance][queueName].Clear();

        // Pause and blueprints reload
        instance.ttPause();
        mainQueue[instance][queueName].AddRange(blueprints[instance][queueName]);

        return instance;
    }


    /// <summary>
    /// Stops and resets the current queue (full queue cleanup).
    /// </summary>
    public static MonoBehaviour ttReset(this MonoBehaviour instance)
    {
        PrepareCurrentQueueName(instance);

        Reset(instance, currentQueueName[instance]);

        return instance;
    }


    /// <summary>
    /// Resume the current queue.
    /// </summary>
    public static MonoBehaviour ttPlay(this MonoBehaviour instance)
    {
        PrepareCurrentQueueName(instance);

        if (debugMode)
            Debug.Log("TeaTime :: ttPlay " + currentQueueName[instance]);

        // Unpauses the queue
        if (IsPaused(instance, currentQueueName[instance]))
            pausedQueues[instance].Remove(currentQueueName[instance]);

        // Execute queue
        instance.StartCoroutine(ExecuteQueue(instance, currentQueueName[instance]));

        return instance;
    }


    /// <summary>
    /// Repeats the current queue n times or infinite (n <= -1).
    /// </summary>
    public static MonoBehaviour ttRepeat(this MonoBehaviour instance, int n = -1)
    {
        PrepareCurrentQueueName(instance);

        if (debugMode)
            Debug.Log("TeaTime :: ttRepeat " + currentQueueName[instance] + ", n = " + n);

        // Ignore locked
        if (IsLocked(instance, currentQueueName[instance]))
            return instance;

        // If infinite
        if (n < 0)
        {
            instance.ttWait();

            PrepareInfiniteQueues(instance);

            if (!infiniteQueues[instance].Contains(currentQueueName[instance]))
                infiniteQueues[instance].Add(currentQueueName[instance]);

            return instance;
        }

        PrepareMainQueue(instance);

        // Repeat n
        while (n-- > 0)
        {
            mainQueue[instance][currentQueueName[instance]].AddRange(blueprints[instance][currentQueueName[instance]]);
        }

        return instance;
    }


    /// <summary>
    /// Creates or changes the current queue.
    /// When used without name the queue id will be random and untrackable.
    /// </summary>
    public static MonoBehaviour tt(this MonoBehaviour instance, string queueName = null)
    {
        if (queueName == null)
            queueName = DEFAULT_QUEUE_NAME + Time.time + UnityEngine.Random.Range(0, int.MaxValue);

        PrepareCurrentQueueName(instance);
        currentQueueName[instance] = queueName;

        return instance;
    }


    /// <summary>
    /// Stops and resets a queue from an instance.
    /// </summary>
    public static void Reset(MonoBehaviour instance, string queueName)
    {
        if (debugMode)
            Debug.Log("TeaTime :: Reset " + queueName + " from " + instance.name);

        PrepareMainQueue(instance, queueName);
        PrepareRunningQueues(instance);
        PrepareLockedQueues(instance);
        PreparePausedQueues(instance);
        PrepareInfiniteQueues(instance);
        PrepareRunningCoroutines(instance, queueName);

        // Clean
        mainQueue[instance][queueName].Clear();

        if (runningQueues[instance].Contains(queueName))
            runningQueues[instance].Remove(queueName);

        if (lockedQueues[instance].Contains(queueName))
            lockedQueues[instance].Remove(queueName);

        if (pausedQueues[instance].Contains(queueName))
            pausedQueues[instance].Remove(queueName);

        if (infiniteQueues[instance].Contains(queueName))
            infiniteQueues[instance].Remove(queueName);

        // Stop & clean coroutines
        foreach (IEnumerator coroutine in runningCoroutines[instance][queueName])
        {
            instance.StopCoroutine(coroutine);
        }
        runningCoroutines[instance][queueName].Clear();
    }


    /// <summary>
    /// Stops and resets all queues from an instance.
    /// </summary>
    public static void Reset(MonoBehaviour instance)
    {
        PrepareMainQueue(instance);
        PrepareRunningQueues(instance);
        PrepareLockedQueues(instance);
        PreparePausedQueues(instance);
        PrepareInfiniteQueues(instance);
        PrepareRunningCoroutines(instance);

        // Clean all
        foreach (KeyValuePair<string, List<ttTask>> taskList in mainQueue[instance])
            taskList.Value.Clear();

        runningQueues[instance].Clear();
        lockedQueues[instance].Clear();
        pausedQueues[instance].Clear();
        infiniteQueues[instance].Clear();

        // Stop & clean coroutines
        foreach (KeyValuePair<string, List<IEnumerator>> coroutineList in runningCoroutines[instance])
        {
            foreach (IEnumerator coroutine in coroutineList.Value)
            {
                instance.StopCoroutine(coroutine);
            }
            coroutineList.Value.Clear();
        }
        runningCoroutines[instance].Clear();
    }


    /// <summary>
    /// Stops and resets all queues in all instances.
    /// </summary>
    public static void ResetAll()
    {
        // Main queue clear
        if (mainQueue != null)
        {
            foreach (KeyValuePair<MonoBehaviour, Dictionary<string, List<ttTask>>> instanceDict in mainQueue)
            {
                foreach (KeyValuePair<string, List<ttTask>> taskList in instanceDict.Value)
                {
                    taskList.Value.Clear();
                }
            }
        }

        // Running queues clear
        if (runningQueues != null)
        {
            foreach (KeyValuePair<MonoBehaviour, List<string>> runningList in runningQueues)
            {
                runningList.Value.Clear();
            }
        }

        // Queues names clear
        if (currentQueueName != null)
        {
            List<MonoBehaviour> keys = new List<MonoBehaviour>(currentQueueName.Keys);
            foreach (MonoBehaviour key in keys)
            {
                currentQueueName[key] = DEFAULT_QUEUE_NAME;
            }
        }

        // Locked queues clear
        if (lockedQueues != null)
        {
            foreach (KeyValuePair<MonoBehaviour, List<string>> lockedList in lockedQueues)
            {
                lockedList.Value.Clear();
            }
        }

        // Paused queues
        if (pausedQueues != null)
        {
            foreach (KeyValuePair<MonoBehaviour, List<string>> pausedList in pausedQueues)
            {
                pausedList.Value.Clear();
            }
        }

        // Infinite queues clear
        if (infiniteQueues != null)
        {
            foreach (KeyValuePair<MonoBehaviour, List<string>> infiniteList in infiniteQueues)
            {
                infiniteList.Value.Clear();
            }
        }

        // Stop & clean all coroutines
        if (runningCoroutines != null)
        {
            foreach (KeyValuePair<MonoBehaviour, Dictionary<string, List<IEnumerator>>> instanceDict in runningCoroutines)
            {
                foreach (KeyValuePair<string, List<IEnumerator>> coroutineList in instanceDict.Value)
                {
                    foreach (IEnumerator coroutine in coroutineList.Value)
                    {
                        instanceDict.Key.StopCoroutine(coroutine);
                    }
                    coroutineList.Value.Clear();
                }
            }
            runningCoroutines.Clear();
        }
    }


    /// <summary>
    /// Executes all timed callbacks and loops for an instance queue.
    /// </summary>
    private static IEnumerator ExecuteQueue(MonoBehaviour instance, string queueName)
    {
        // Ignore if the queue is empty
        if (!mainQueue[instance].ContainsKey(queueName) || mainQueue[instance][queueName].Count < 1)
            yield break;

        PrepareRunningQueues(instance);

        // Ignore if already running
        if (runningQueues.ContainsKey(instance) && runningQueues[instance].Contains(queueName))
            yield break;

        // Marks the queue as running
        runningQueues[instance].Add(queueName);

        // Coroutines registry
        PrepareRunningCoroutines(instance, queueName);
        IEnumerator coroutine = null;

        // Run over a clone until depleted
        List<ttTask> batch = new List<ttTask>();
        batch.AddRange(mainQueue[instance][queueName]);

        foreach (ttTask task in batch)
        {
            // Selection
            if (task.isLoop)
            {
                if (task.time > 0)
                {
                    coroutine = ExecuteLoop(task.instance, task.queueName, task.time, task.callbackWithHandler);
                }
                else
                {
                    coroutine = ExecuteInfiniteLoop(task.instance, task.queueName, task.callbackWithHandler);
                }
            }
            else
            {
                coroutine = ExecuteOnce(task.instance, task.queueName, task.time, task.yieldInstruction, task.callback, task.callbackWithHandler);
            }

            // Register and execute coroutines
            runningCoroutines[instance][queueName].Add(coroutine);
            yield return instance.StartCoroutine(coroutine);
            runningCoroutines[instance][queueName].Remove(coroutine);

            // Done!
            mainQueue[instance][queueName].Remove(task);
        }

        // The queue has stopped
        runningQueues[instance].Remove(queueName);

        // Try again is there are new items
        if (mainQueue[instance][queueName].Count > 0)
        {
            instance.StartCoroutine(ExecuteQueue(instance, queueName));
        }
        else
        {
            // Repeat if infinite
            if (IsInfinite(instance, queueName))
            {
                mainQueue[instance][queueName].AddRange(blueprints[instance][queueName]);
                instance.StartCoroutine(ExecuteQueue(instance, queueName));
            }
            // Queue completed, remove the lock
            else
            {
                if (IsLocked(instance, queueName))
                    lockedQueues[instance].Remove(queueName);
            }
        }

    }


    /// <summary>
    /// Executes a timed callback.
    /// </summary>
    private static IEnumerator ExecuteOnce(MonoBehaviour instance, string queueName, float timeToWait, YieldInstruction yieldToWait,
                                           Action callback, Action<ttHandler> callbackWithHandler)
    {
        // Pause
        while (IsPaused(instance, queueName))
            yield return null;

        // Wait until
        if (timeToWait > 0)
            yield return new WaitForSeconds(timeToWait);

        if (yieldToWait != null)
            yield return yieldToWait;

        // Executes the normal callback
        if (callback != null)
            callback();

        // Executes the callback with handler (and waits his yield)
        if (callbackWithHandler != null)
        {
            ttHandler t = new ttHandler();
            callbackWithHandler(t);

            if (t.yieldToWait != null)
                yield return t.yieldToWait;
        }

        yield return null;
    }


    /// <summary>
    /// Executes a callback inside a loop for all his duration or until ttHandler.Break().
    /// </summary>
    private static IEnumerator ExecuteLoop(MonoBehaviour instance, string queueName, float duration, Action<ttHandler> callback)
    {
        // Only for positive values
        if (duration <= 0)
            yield break;

        // Handler data
        ttHandler loopHandler = new ttHandler();
        float tRate = 1 / duration;

        // Run while active until duration
        while (loopHandler.isActive && loopHandler.t < 1)
        {
            // deltatime
            float unityTimeDelta = Time.deltaTime;

            // Completion % from 0 to 1
            loopHandler.t += tRate * unityTimeDelta;

            // Customized delta that represents the loop duration
            loopHandler.deltaTime = 1 / (duration - loopHandler.timeSinceStart) * unityTimeDelta;
            loopHandler.timeSinceStart += unityTimeDelta;

            // Pause
            while (IsPaused(instance, queueName))
                yield return null;

            // Execute
            if (callback != null)
                callback(loopHandler);

            // Yields once
            if (loopHandler.yieldToWait != null)
            {
                yield return loopHandler.yieldToWait;
                loopHandler.yieldToWait = null;
            }

            yield return null;
        }
    }


    /// <summary>
    /// Executes a callback inside an infinite loop until ttHandler.Break().
    /// </summary>
    private static IEnumerator ExecuteInfiniteLoop(MonoBehaviour instance, string queueName, Action<ttHandler> callback)
    {
        ttHandler loopHandler = new ttHandler();

        // Run while active
        while (loopHandler.isActive)
        {
            // deltaTime
            float delta = Time.deltaTime;
            loopHandler.deltaTime = delta;
            loopHandler.timeSinceStart += delta;

            // Pause
            while (IsPaused(instance, queueName))
                yield return null;

            // Execute
            if (callback != null)
                callback(loopHandler);

            // Yields once
            if (loopHandler.yieldToWait != null)
            {
                yield return loopHandler.yieldToWait;
                loopHandler.yieldToWait = null;
            }

            yield return null;
        }
    }
}
